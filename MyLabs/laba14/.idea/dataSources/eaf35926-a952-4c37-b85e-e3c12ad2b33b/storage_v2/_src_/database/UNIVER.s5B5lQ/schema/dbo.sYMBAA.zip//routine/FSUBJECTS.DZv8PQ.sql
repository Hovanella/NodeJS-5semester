
create function FSUBJECTS(@p varchar(20)) returns varchar(300)
as begin
declare @sb varchar(10), @s varchar(100) = '';
declare sbj cursor local for
            select distinct SUBJECT from SUBJECT where PULPIT like @p;
open sbj;
    fetch sbj into @sb;
    while @@FETCH_STATUS = 0
    begin
        set @s = @s + RTRIM(@sb) + ', ';
        fetch sbj into @sb;
    end;
close sbj;
return @s
end;
go

