
create function FACULTY_REPORT(@c int) returns @fr table
	([Факультет] varchar(50),
	[Количество кафедр] int,
	[Количество групп] int,
	[Количество студентов] int,
	[Количество специальностей] int)
	as begin
		declare cc cursor local static for
			select FACULTY from FACULTY where dbo.COUNT_STUDENTS(FACULTY.FACULTY) > @c;
		declare @f varchar(30);
		open cc;
			fetch cc into @f;
		while @@fetch_status = 0
			begin
				insert @fr values(
				@f,
				dbo.COUNT_PULPIT(@f),
	            dbo.COUNT_GROUPS(@f),
				dbo.COUNT_STUDENTS(@f),
				dbo.COUNT_PROFESSION(@f));
	            fetch cc into @f;
			end;
		close cc;
		deallocate cc;
		return;
	end;
go

