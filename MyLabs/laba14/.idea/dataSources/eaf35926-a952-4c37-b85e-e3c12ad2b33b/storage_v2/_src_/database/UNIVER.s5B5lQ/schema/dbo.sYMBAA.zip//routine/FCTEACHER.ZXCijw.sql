
create function FCTEACHER(@pul nvarchar(10)) returns int as
    begin
        declare @count int=(select count(*) from TEACHER
        where PULPIT=isnull(@pul, PULPIT));
        return @count;
    end;
go

