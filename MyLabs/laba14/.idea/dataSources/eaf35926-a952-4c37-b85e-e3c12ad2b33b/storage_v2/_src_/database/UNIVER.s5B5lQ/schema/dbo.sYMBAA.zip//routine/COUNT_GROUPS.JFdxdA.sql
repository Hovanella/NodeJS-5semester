
create function COUNT_GROUPS(@faculty nvarchar(10)) returns int
as begin
    declare @rc int=0;
    set @rc=(select count(*) from GROUPS
        where GROUPS.FACULTY=@faculty)
    return @rc;
end;

go

