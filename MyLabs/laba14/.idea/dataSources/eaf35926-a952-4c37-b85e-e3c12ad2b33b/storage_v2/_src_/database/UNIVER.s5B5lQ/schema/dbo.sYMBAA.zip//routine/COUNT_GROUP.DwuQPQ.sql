create function COUNT_GROUP(@f varchar(20)) returns int
as begin
declare @rc int = 0;
set @rc = (select count(IDGROUP) from [GROUP] where FACULTY like @f);
return @rc;
end
go

